import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:truejobs/constants/app_colors.dart';
import 'package:truejobs/widgets/custom_app_bar.dart';
import 'package:truejobs/services/basic_detail_api_service.dart';
import 'package:truejobs/services/company_details_api_service.dart';
import 'package:truejobs/services/dropdown_apis/industry_type_api_service.dart';
import 'package:image_picker/image_picker.dart';

import 'bottom_sheets/image_picker_sheet.dart';

class CompanyProfileScreen extends StatefulWidget {
  const CompanyProfileScreen({super.key});

  @override
  State<CompanyProfileScreen> createState() => _CompanyProfileScreenState();
}

class _CompanyProfileScreenState extends State<CompanyProfileScreen> {
  static const String _fontFamily = 'Poppins';

  bool _isLoading = true;
  bool _isSaving = false;

  final TextEditingController _companyNameCtrl = TextEditingController();
  final TextEditingController _pincodeCtrl = TextEditingController();
  final TextEditingController _addressCtrl = TextEditingController();
  final TextEditingController _aboutCtrl = TextEditingController();
  final TextEditingController _sizeCtrl = TextEditingController();
  final TextEditingController _foundedYearCtrl = TextEditingController();
  final TextEditingController _mobileCtrl = TextEditingController();
  final TextEditingController _emailCtrl = TextEditingController();
  final TextEditingController _websiteCtrl = TextEditingController();
  final TextEditingController _linkedinCtrl = TextEditingController();

  String _industryTypeId = '';
  String _industryTypeName = '';
  String? _companyLogoPath;
  List<String> _ourCulturePaths = [];

  String _userId = '';
  String _token = '';

  List<dynamic> _industryOptions = [];
  String? _editingField;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  @override
  void dispose() {
    _companyNameCtrl.dispose();
    _pincodeCtrl.dispose();
    _addressCtrl.dispose();
    _aboutCtrl.dispose();
    _sizeCtrl.dispose();
    _foundedYearCtrl.dispose();
    _mobileCtrl.dispose();
    _emailCtrl.dispose();
    _websiteCtrl.dispose();
    _linkedinCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);

    final prefs = await SharedPreferences.getInstance();
    _userId = prefs.getInt('user_id')?.toString() ?? '';
    _token = prefs.getString('token') ?? '';

    _industryOptions = await IndustryTypeApiService.fetchIndustryTypes();

    final response = await BasicDetailApiService.fetchBasicDetails(
      userId: _userId,
      token: _token,
    );

    if (response != null && response['status'] == 'success') {
      final data = response['data'];
      if (data != null) {
        _companyNameCtrl.text = data['company_name'] ?? data['company'] ?? '';
        _pincodeCtrl.text = data['pincode'] ?? data['pin_code'] ?? '';
        _addressCtrl.text = data['address'] ?? data['company_address'] ?? '';
        _aboutCtrl.text = data['company_description'] ?? data['about_company'] ?? '';
        _sizeCtrl.text = data['company_size']?.toString() ?? '';
        _foundedYearCtrl.text = data['founded_year']?.toString() ?? '';
        _mobileCtrl.text = data['company_mobile'] ?? '';
        _emailCtrl.text = data['company_email'] ?? '';
        _websiteCtrl.text = data['company_website'] ?? '';
        _linkedinCtrl.text = data['linkedin_url'] ?? '';

        final indType = data['industry_type'] ?? data['industry'];
        if (indType != null && indType.toString().isNotEmpty) {
          _industryTypeId = indType.toString();
          _updateIndustryName();
        }
        final logo = data['company_logo'];
        if (logo != null && logo.toString().isNotEmpty) {
          _companyLogoPath = logo.toString();
        }
      }
    }
    setState(() => _isLoading = false);
  }

  void _updateIndustryName() {
    _industryTypeName = '';
    for (var e in _industryOptions) {
      if ((e['value'] ?? e['id'])?.toString() == _industryTypeId) {
        _industryTypeName = (e['label'] ?? e['name'])?.toString() ?? '';
        break;
      }
    }
  }

  Future<void> _handleSave() async {
    final companyName = _companyNameCtrl.text.trim();
    final pincode = _pincodeCtrl.text.trim();
    final address = _addressCtrl.text.trim();
    final about = _aboutCtrl.text.trim();
    final size = _sizeCtrl.text.trim();
    final foundedYear = _foundedYearCtrl.text.trim();
    final mobile = _mobileCtrl.text.trim();
    final email = _emailCtrl.text.trim();
    final website = _websiteCtrl.text.trim();
    final linkedin = _linkedinCtrl.text.trim();

    if (companyName.isEmpty ||
        pincode.isEmpty ||
        address.isEmpty ||
        _industryTypeId.isEmpty ||
        about.isEmpty ||
        size.isEmpty ||
        foundedYear.isEmpty ||
        mobile.isEmpty ||
        email.isEmpty ||
        website.isEmpty ||
        linkedin.isEmpty ||
        _companyLogoPath == null ||
        _companyLogoPath!.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all the required fields')),
      );
      return;
    }

    setState(() => _isSaving = true);
    FocusScope.of(context).unfocus();

    final response = await CompanyDetailsApiService.updateDetails(
      userId: _userId,
      companyName: companyName,
      pincode: pincode,
      address: address,
      industryType: _industryTypeId,
      token: _token,
      aboutCompany: about,
      companySize: size,
      foundedYear: foundedYear,
      companyMobile: mobile,
      companyEmail: email,
      companyWebsite: website,
      linkedinUrl: linkedin,
      companyLogoFile: _companyLogoPath,
      ourCulture: _ourCulturePaths,
    );

    setState(() {
      _isSaving = false;
      _editingField = null;
    });

    if (response != null && response['status'] == 'success') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Company profile updated successfully')),
      );
      Navigator.pop(context, true);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(response?['message'] ?? 'Failed to update details')),
      );
    }
  }

  void _pickImages() async {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16.r))),
      builder: (context) => const ImagePickerSheet(),
    ).then((val) async {
      if (val != null && val is String) {
        final ImagePicker picker = ImagePicker();
        if (val == 'camera') {
          XFile? pickedFile = await picker.pickImage(source: ImageSource.camera);
          if (pickedFile != null) setState(() => _ourCulturePaths.add(pickedFile.path));
        } else if (val == 'gallery') {
          final List<XFile> pickedFiles = await picker.pickMultiImage();
          if (pickedFiles.isNotEmpty) {
            setState(() {
              for (var file in pickedFiles) {
                _ourCulturePaths.add(file.path);
              }
            });
          }
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F8FD),
      body: SafeArea(
        top: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const CustomAppBar(backgroundColor: Color(0xFFF6F8FD)),
            SizedBox(height: 24.h),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 18.w),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Icon(Icons.arrow_back_ios, color: AppColors.dynamicText, size: 18.w),
                  ),
                  SizedBox(width: 8.w),
                  Text('Company Profile', style: TextStyle(fontFamily: _fontFamily, fontSize: 16.sp, fontWeight: FontWeight.w600, color: AppColors.dynamicText)),
                ],
              ),
            ),
            SizedBox(height: 10.h),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 18.w),
              child: Text('View your registered information below', style: TextStyle(fontFamily: _fontFamily, fontSize: 12.sp, color: AppColors.dynamicSubtitle)),
            ),
            SizedBox(height: 20.h),
            Expanded(
              child: _isLoading
                  ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
                  : SingleChildScrollView(
                      padding: EdgeInsets.symmetric(horizontal: 18.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildCard(_buildLogoRow()),
                          
                          SizedBox(height: 16.h),
                          Text('Basic Details', style: _sectionTitleStyle()),
                          SizedBox(height: 16.h),
                          _buildCardColumn([
                            _buildEditableRow('company_name', 'Company Name', _companyNameCtrl, 'assets/settings_icon/company_name.png'),
                            const Divider(color: Color(0xFFE3E3E3), height: 1),
                            _buildIndustryRow(),
                            const Divider(color: Color(0xFFE3E3E3), height: 1),
                            _buildEditableRow('address', 'Company Address', _addressCtrl, 'assets/settings_icon/address.png', maxLines: 2),
                            const Divider(color: Color(0xFFE3E3E3), height: 1),
                            _buildEditableRow('pincode', 'Pin code', _pincodeCtrl, 'assets/settings_icon/pincode.png', isNumber: true),
                            const Divider(color: Color(0xFFE3E3E3), height: 1),
                            _buildEditableRow('about', 'About', _aboutCtrl, 'assets/settings_icon/about_company.png', maxLines: 3),
                          ]),
                          
                          SizedBox(height: 24.h),
                          Text('Additional Information', style: _sectionTitleStyle()),
                          SizedBox(height: 16.h),
                          _buildCardColumn([
                            _buildEditableRow('size', 'Company Size', _sizeCtrl, 'assets/settings_icon/company_name.png', isNumber: true),
                            const Divider(color: Color(0xFFE3E3E3), height: 1),
                            _buildEditableRow('founded', 'Founded Year', _foundedYearCtrl, 'assets/settings_icon/company_name.png', isNumber: true),
                          ]),
                          
                          SizedBox(height: 24.h),
                          Text('Contact Information', style: _sectionTitleStyle()),
                          SizedBox(height: 16.h),
                          _buildCardColumn([
                            _buildEditableRow('mobile', 'Company Mobile', _mobileCtrl, 'assets/settings_icon/company_name.png', isNumber: true),
                            const Divider(color: Color(0xFFE3E3E3), height: 1),
                            _buildEditableRow('email', 'Company Email', _emailCtrl, 'assets/settings_icon/company_name.png'),
                            const Divider(color: Color(0xFFE3E3E3), height: 1),
                            _buildEditableRow('website', 'Company Website', _websiteCtrl, 'assets/settings_icon/company_name.png'),
                            const Divider(color: Color(0xFFE3E3E3), height: 1),
                            _buildEditableRow('linkedin', 'LinkedIn URL', _linkedinCtrl, 'assets/settings_icon/company_name.png'),
                          ]),
                          
                          SizedBox(height: 24.h),
                          Text('Company Gallery', style: _sectionTitleStyle()),
                          SizedBox(height: 4.h),
                          Text('Showcase your workplace, team, and culture', style: TextStyle(fontFamily: _fontFamily, fontSize: 11.sp, color: AppColors.dynamicSubtitle)),
                          SizedBox(height: 16.h),
                          _buildGalleryUpload(),
                          
                          SizedBox(height: 32.h),
                          
                          SizedBox(
                            width: double.infinity,
                            height: 44.h,
                            child: ElevatedButton(
                              onPressed: _isSaving ? null : _handleSave,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF1462FD),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22.r)),
                              ),
                              child: _isSaving
                                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                                  : Text('Save', style: TextStyle(fontFamily: _fontFamily, fontSize: 16.sp, fontWeight: FontWeight.w600, color: Colors.white)),
                            ),
                          ),
                          SizedBox(height: 40.h),
                        ],
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
  
  TextStyle _sectionTitleStyle() {
    return TextStyle(fontFamily: _fontFamily, fontSize: 14.sp, fontWeight: FontWeight.w600, color: AppColors.dynamicText);
  }

  Widget _buildCard(Widget child) {
    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12.r)),
      child: child,
    );
  }
  
  Widget _buildCardColumn(List<Widget> children) {
    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12.r)),
      child: Column(children: children),
    );
  }

  Widget _buildLogoRow() {
    return Row(
      children: [
        Container(
          width: 50.w,
          height: 50.w,
          decoration: BoxDecoration(
            color: const Color(0xFFEAEFFC),
            shape: BoxShape.circle,
            image: _companyLogoPath != null && _companyLogoPath!.isNotEmpty
                ? DecorationImage(
                    image: _companyLogoPath!.startsWith('http')
                        ? NetworkImage(_companyLogoPath!) as ImageProvider
                        : FileImage(File(_companyLogoPath!)),
                    fit: BoxFit.cover,
                  )
                : null,
          ),
          child: _companyLogoPath == null ? Icon(Icons.business, color: const Color(0xFF1462FD), size: 24.w) : null,
        ),
        SizedBox(width: 16.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Company Logo', style: TextStyle(fontFamily: _fontFamily, fontSize: 13.sp, fontWeight: FontWeight.w500, color: AppColors.dynamicText)),
              SizedBox(height: 8.h),
              GestureDetector(
                onTap: () {
                  showModalBottomSheet(
                    context: context,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16.r))),
                    builder: (context) => const ImagePickerSheet(),
                  ).then((val) async {
                    if (val != null && val is String) {
                      final ImagePicker picker = ImagePicker();
                      XFile? pickedFile;
                      if (val == 'camera') pickedFile = await picker.pickImage(source: ImageSource.camera);
                      else if (val == 'gallery') pickedFile = await picker.pickImage(source: ImageSource.gallery);
                      if (pickedFile != null) setState(() => _companyLogoPath = pickedFile!.path);
                    }
                  });
                },
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                  decoration: BoxDecoration(border: Border.all(color: const Color(0xFF1462FD)), borderRadius: BorderRadius.circular(4.r)),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.camera_alt_outlined, color: const Color(0xFF1462FD), size: 14.sp),
                      SizedBox(width: 6.w),
                      Text(_companyLogoPath == null || _companyLogoPath!.isEmpty ? 'Add logo' : 'Change logo', style: TextStyle(fontFamily: _fontFamily, fontSize: 12.sp, color: const Color(0xFF1462FD))),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
  
  Widget _buildIndustryRow() {
    final bool isEmpty = _industryTypeId.isEmpty;
    final bool isEditing = _editingField == 'industry';
    
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            padding: EdgeInsets.all(8.w),
            decoration: BoxDecoration(color: const Color(0xFFEAEFFC), borderRadius: BorderRadius.circular(10.r)),
            child: Image.asset('assets/settings_icon/industry.png', height: 20.h, width: 20.w),
          ),
          SizedBox(width: 16.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Industry', style: TextStyle(fontFamily: _fontFamily, fontSize: 11.sp, color: AppColors.dynamicSubtitle)),
                SizedBox(height: 4.h),
                if (isEditing)
                  DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      isExpanded: true,
                      value: _industryTypeId.isNotEmpty ? _industryTypeId : null,
                      hint: Text('Select Industry', style: TextStyle(fontFamily: _fontFamily, fontSize: 13.sp, color: AppColors.dynamicSubtitle)),
                      items: _industryOptions.map((e) {
                        final val = (e['value'] ?? e['id'])?.toString() ?? '';
                        final label = (e['label'] ?? e['name'])?.toString() ?? '';
                        return DropdownMenuItem(value: val, child: Text(label, style: TextStyle(fontFamily: _fontFamily, fontSize: 13.sp)));
                      }).toList(),
                      onChanged: (val) {
                        setState(() {
                          _industryTypeId = val ?? '';
                          _updateIndustryName();
                          _editingField = null;
                        });
                      },
                    ),
                  )
                else
                  Text(
                    isEmpty ? 'Not Available' : _industryTypeName,
                    style: TextStyle(fontFamily: _fontFamily, fontSize: 13.sp, fontWeight: isEmpty ? FontWeight.w400 : FontWeight.w500, color: isEmpty ? AppColors.dynamicSubtitle : AppColors.dynamicText),
                  ),
              ],
            ),
          ),
          if (!isEditing) SizedBox(width: 8.w),
          if (!isEditing)
            GestureDetector(
              onTap: () => setState(() => _editingField = 'industry'),
              child: Container(
                padding: EdgeInsets.all(8.w),
                decoration: const BoxDecoration(color: Color(0xFFF4F6FA), shape: BoxShape.circle),
                child: Icon(isEmpty ? Icons.add : Icons.edit, color: const Color(0xFF055BF2), size: 15.w),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildEditableRow(String fieldKey, String title, TextEditingController controller, String iconPath, {bool isNumber = false, int maxLines = 1}) {
    final bool isEmpty = controller.text.trim().isEmpty;
    final bool isEditing = _editingField == fieldKey;

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      child: Row(
        crossAxisAlignment: isEditing && maxLines > 1 ? CrossAxisAlignment.start : CrossAxisAlignment.center,
        children: [
          Container(
            padding: EdgeInsets.all(8.w),
            decoration: BoxDecoration(color: const Color(0xFFEAEFFC), borderRadius: BorderRadius.circular(10.r)),
            child: Image.asset(iconPath, height: 20.h, width: 20.w, errorBuilder: (c, e, s) => Icon(Icons.info_outline, color: const Color(0xFF1462FD), size: 20.w)),
          ),
          SizedBox(width: 16.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontFamily: _fontFamily, fontSize: 11.sp, color: AppColors.dynamicSubtitle)),
                SizedBox(height: 4.h),
                if (isEditing)
                  TextField(
                    controller: controller,
                    autofocus: true,
                    keyboardType: isNumber ? TextInputType.number : TextInputType.text,
                    maxLines: maxLines,
                    style: TextStyle(fontFamily: _fontFamily, fontSize: 13.sp, fontWeight: FontWeight.w500, color: AppColors.dynamicText),
                    decoration: InputDecoration(
                      isDense: true,
                      contentPadding: EdgeInsets.symmetric(vertical: 4.h),
                      border: const UnderlineInputBorder(borderSide: BorderSide(color: Color(0xFF1462FD))),
                    ),
                    onSubmitted: (_) => setState(() => _editingField = null),
                  )
                else
                  Text(
                    isEmpty ? 'Not Available' : controller.text,
                    style: TextStyle(fontFamily: _fontFamily, fontSize: 13.sp, fontWeight: isEmpty ? FontWeight.w400 : FontWeight.w500, color: isEmpty ? AppColors.dynamicSubtitle : AppColors.dynamicText),
                    maxLines: maxLines,
                    overflow: maxLines == 1 ? TextOverflow.ellipsis : null,
                  ),
              ],
            ),
          ),
          if (!isEditing) SizedBox(width: 8.w),
          if (!isEditing)
            GestureDetector(
              onTap: () => setState(() => _editingField = fieldKey),
              child: Container(
                padding: EdgeInsets.all(8.w),
                decoration: const BoxDecoration(color: Color(0xFFF4F6FA), shape: BoxShape.circle),
                child: Icon(isEmpty ? Icons.add : Icons.edit, color: const Color(0xFF055BF2), size: 15.w),
              ),
            ),
          if (isEditing) SizedBox(width: 8.w),
          if (isEditing)
             GestureDetector(
              onTap: () => setState(() => _editingField = null),
              child: Container(
                padding: EdgeInsets.all(8.w),
                decoration: const BoxDecoration(color: Color(0xFFF4F6FA), shape: BoxShape.circle),
                child: Icon(Icons.check, color: const Color(0xFF055BF2), size: 15.w),
              ),
            ),
        ],
      ),
    );
  }
  
  Widget _buildGalleryUpload() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(vertical: 24.h),
      decoration: BoxDecoration(
        color: const Color(0xFFF4F6FA),
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: const Color(0xFFD3D8E2), style: BorderStyle.solid), // Dashed border technically, but solid is easier without a package
      ),
      child: GestureDetector(
        onTap: _pickImages,
        behavior: HitTestBehavior.opaque,
        child: Column(
          children: [
            Icon(Icons.cloud_upload_outlined, color: const Color(0xFF1462FD), size: 32.w),
            SizedBox(height: 8.h),
            Text('Upload Images', style: TextStyle(fontFamily: _fontFamily, fontSize: 13.sp, fontWeight: FontWeight.w600, color: AppColors.dynamicText)),
            SizedBox(height: 4.h),
            RichText(
              text: TextSpan(
                text: 'Drag and drop images or click to ',
                style: TextStyle(fontFamily: _fontFamily, fontSize: 11.sp, color: AppColors.dynamicSubtitle),
                children: const [
                  TextSpan(text: 'browse', style: TextStyle(color: Color(0xFF1462FD), fontWeight: FontWeight.w600)),
                ],
              ),
            ),
            if (_ourCulturePaths.isNotEmpty) ...[
              SizedBox(height: 16.h),
              Wrap(
                spacing: 8.w,
                runSpacing: 8.h,
                children: _ourCulturePaths.map((path) {
                  return Stack(
                    children: [
                      Container(
                        width: 60.w,
                        height: 60.w,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8.r),
                          image: DecorationImage(
                            image: path.startsWith('http') ? NetworkImage(path) as ImageProvider : FileImage(File(path)),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      Positioned(
                        right: -4,
                        top: -4,
                        child: GestureDetector(
                          onTap: () => setState(() => _ourCulturePaths.remove(path)),
                          child: Container(
                            padding: EdgeInsets.all(2.w),
                            decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                            child: const Icon(Icons.cancel, size: 16, color: Colors.red),
                          ),
                        ),
                      ),
                    ],
                  );
                }).toList(),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
