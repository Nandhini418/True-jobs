import 'package:flutter/material.dart';
import 'package:truejobs/constants/app_colors.dart';

class NotificationScreen extends StatelessWidget {
  const NotificationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final Size screenSize = MediaQuery.of(context).size;
    final double sw = screenSize.width;
    final Color bgColor = AppColors.dynamicBg;
    final Color textColor = AppColors.dynamicText;
    final Color subtitleColor = AppColors.dynamicSubtitle;
    final Color cardBg = AppColors.dynamicCardBg;
    final Color borderColor = AppColors.dynamicBorder;

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: bgColor,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios, color: textColor, size: sw * 0.05),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          'True Notify',
          style: TextStyle(
            color: textColor,
            fontSize: sw * 0.055,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: false,
      ),
      body: ListView(
        padding: EdgeInsets.symmetric(horizontal: sw * 0.04),
        children: [
          _buildSectionHeader('Today', sw, subtitleColor),
          _buildNotificationCard(
            context: context,
            title: 'New job matches your profile!',
            subtitle: '"UI/UX Designer roles available near you. Apply now!"',
            time: '1h ago',
            icon: Icons.work,
            iconBgColor: Colors.grey.shade100,
            iconColor: Colors.blueGrey,
            buttonText: 'View jobs',
            hasTintBg: true,
            sw: sw,
            cardBg: cardBg,
            textColor: textColor,
            subtitleColor: subtitleColor,
            borderColor: borderColor,
          ),
          _buildNotificationCard(
            context: context,
            title: 'Walk-in Interview Today!',
            subtitle: 'Direct hiring for Sales Executives – 10 AM to 4 PM"',
            time: '1h ago',
            icon: Icons.groups,
            iconBgColor: Colors.purple.shade50,
            iconColor: AppColors.primary,
            hasTintBg: true,
            sw: sw,
            cardBg: cardBg,
            textColor: textColor,
            subtitleColor: subtitleColor,
            borderColor: borderColor,
          ),
          _buildNotificationCard(
            context: context,
            title: 'Unlock Premium Jobs',
            subtitle: 'Get access to exclusive job openings',
            time: '3h ago',
            icon: Icons.workspace_premium,
            iconBgColor: Colors.green.shade50,
            iconColor: Colors.green.shade700,
            hasTintBg: false,
            sw: sw,
            cardBg: cardBg,
            textColor: textColor,
            subtitleColor: subtitleColor,
            borderColor: borderColor,
          ),
          _buildSectionHeader('Yesterday', sw, subtitleColor),
          _buildNotificationCard(
            context: context,
            title: 'Application Viewed',
            subtitle: 'Your profile was viewed by XYZ Company',
            time: '1d ago',
            icon: Icons.visibility,
            iconBgColor: Colors.green.shade50,
            iconColor: Colors.green.shade700,
            buttonText: 'View',
            hasTintBg: false,
            sw: sw,
            cardBg: cardBg,
            textColor: textColor,
            subtitleColor: subtitleColor,
            borderColor: borderColor,
          ),
          _buildNotificationCard(
            context: context,
            title: 'Jobs near you !',
            subtitle: '10+ openings in Coimbatore. Don’t miss out!',
            time: '1d ago',
            icon: Icons.visibility,
            iconBgColor: Colors.green.shade50,
            iconColor: Colors.green.shade700,
            buttonText: 'View Jobs',
            hasTintBg: false,
            sw: sw,
            cardBg: cardBg,
            textColor: textColor,
            subtitleColor: subtitleColor,
            borderColor: borderColor,
          ),
          _buildNotificationCard(
            context: context,
            title: 'Get Hired Faster 🎉',
            subtitle: 'A strong ATS resume increases your chances by 3x. Start now!',
            time: '1d ago',
            icon: Icons.description,
            iconBgColor: Colors.blue.shade50,
            iconColor: Colors.blue.shade700,
            hasActionButtons: true,
            hasTintBg: false,
            sw: sw,
            cardBg: cardBg,
            textColor: textColor,
            subtitleColor: subtitleColor,
            borderColor: borderColor,
          ),
          SizedBox(height: sw * 0.05),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title, double sw, Color subtitleColor) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: sw * 0.04),
      child: Text(
        title,
        style: TextStyle(
          color: subtitleColor,
          fontSize: sw * 0.04,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildNotificationCard({
    required BuildContext context,
    required String title,
    required String subtitle,
    required String time,
    required IconData icon,
    required Color iconBgColor,
    required Color iconColor,
    String? buttonText,
    bool hasActionButtons = false,
    required bool hasTintBg,
    required double sw,
    required Color cardBg,
    required Color textColor,
    required Color subtitleColor,
    required Color borderColor,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: sw * 0.03),
      padding: EdgeInsets.all(sw * 0.04),
      decoration: BoxDecoration(
        color: hasTintBg ? const Color(0xFFFAF2FB) : cardBg,
        borderRadius: BorderRadius.circular(sw * 0.03),
        border: hasTintBg ? null : Border.all(color: borderColor),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Icon Container
          Container(
            padding: EdgeInsets.all(sw * 0.03),
            decoration: BoxDecoration(
              color: iconBgColor,
              borderRadius: BorderRadius.circular(sw * 0.03),
            ),
            child: Icon(icon, color: iconColor, size: sw * 0.06),
          ),
          SizedBox(width: sw * 0.04),
          // Content
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(
                        title,
                        style: TextStyle(
                          color: textColor,
                          fontWeight: FontWeight.bold,
                          fontSize: sw * 0.04,
                        ),
                      ),
                    ),
                    Text(
                      time,
                      style: TextStyle(
                        color: subtitleColor,
                        fontSize: sw * 0.03,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: sw * 0.015),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: subtitleColor,
                    fontSize: sw * 0.035,
                    height: 1.2,
                  ),
                ),
                if (buttonText != null) ...[
                  SizedBox(height: sw * 0.03),
                  OutlinedButton(
                    onPressed: () {},
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: AppColors.iconGreen),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(sw * 0.04),
                      ),
                      padding: EdgeInsets.symmetric(horizontal: sw * 0.05, vertical: 0),
                      minimumSize: Size(0, sw * 0.08),
                    ),
                    child: Text(
                      buttonText,
                      style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.bold,
                        fontSize: sw * 0.032,
                      ),
                    ),
                  ),
                ],
                if (hasActionButtons) ...[
                  SizedBox(height: sw * 0.03),
                  Row(
                    children: [
                      ElevatedButton(
                        onPressed: () {},
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primary,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(sw * 0.02),
                          ),
                          padding: EdgeInsets.symmetric(horizontal: sw * 0.04),
                          minimumSize: Size(0, sw * 0.08),
                          elevation: 0,
                        ),
                        child: Text(
                          'Create Cv',
                          style: TextStyle(
                            fontSize: sw * 0.032,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(width: sw * 0.03),
                      OutlinedButton(
                        onPressed: () {},
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppColors.primary,
                          side: const BorderSide(color: AppColors.primary),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(sw * 0.02),
                          ),
                          padding: EdgeInsets.symmetric(horizontal: sw * 0.04),
                          minimumSize: Size(0, sw * 0.08),
                        ),
                        child: Text(
                          'No, thanks!',
                          style: TextStyle(
                            fontSize: sw * 0.032,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
