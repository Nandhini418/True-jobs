class ResumeData {
  final String fullName;
  final String role;
  final String email;
  final String phone;
  final String address;
  final String summary;
  final List<Education> education;
  final List<Experience> experience;
  final List<String> skills;
  final bool hasPhoto; // Used for "With photo" / "Without photo" variations

  ResumeData({
    required this.fullName,
    required this.role,
    required this.email,
    required this.phone,
    required this.address,
    required this.summary,
    required this.education,
    required this.experience,
    required this.skills,
    this.hasPhoto = false,
  });

  // Dummy data for template preview
  static ResumeData dummyData({bool withPhoto = false}) {
    return ResumeData(
      fullName: 'Alex Johnson',
      role: 'Software Engineer',
      email: 'alex.johnson@email.com',
      phone: '+1 234 567 8900',
      address: 'New York, NY 10001',
      summary: 'Passionate and results-driven Software Engineer with 3+ years of experience in developing scalable web applications. Proficient in Flutter, Dart, and building user-centric interfaces. Strong problem-solving skills and a team player.',
      education: [
        Education(
          degree: 'B.S. in Computer Science',
          institution: 'State University',
          year: '2018 - 2022',
        ),
      ],
      experience: [
        Experience(
          jobTitle: 'Frontend Developer',
          company: 'Tech Solutions Inc.',
          duration: 'Jan 2023 - Present',
          description: 'Developed and maintained cross-platform mobile applications using Flutter. Improved app performance by 30% and successfully delivered 4 major releases.',
        ),
        Experience(
          jobTitle: 'Software Engineering Intern',
          company: 'Innovate LLC',
          duration: 'Jun 2022 - Dec 2022',
          description: 'Assisted in building responsive web components and optimizing REST APIs.',
        ),
      ],
      skills: ['Flutter', 'Dart', 'JavaScript', 'React', 'Git', 'Agile', 'UI/UX Design'],
      hasPhoto: withPhoto,
    );
  }
}

class Education {
  final String degree;
  final String institution;
  final String year;

  Education({
    required this.degree,
    required this.institution,
    required this.year,
  });
}

class Experience {
  final String jobTitle;
  final String company;
  final String duration;
  final String description;

  Experience({
    required this.jobTitle,
    required this.company,
    required this.duration,
    required this.description,
  });
}
