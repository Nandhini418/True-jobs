import 'package:flutter/foundation.dart';
import 'package:google_mlkit_translation/google_mlkit_translation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class TranslationManager extends ChangeNotifier {
  static final TranslationManager instance = TranslationManager._internal();
  TranslationManager._internal();

  String _currentLanguage = 'English';
  String get currentLanguage => _currentLanguage;

  OnDeviceTranslator? _translator;
  bool _isModelReady = false;

  final Map<String, String> _cache = {};
  bool _isInitStarted = false;

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _currentLanguage = prefs.getString('language') ?? 'English';
    if (_currentLanguage == 'Tamil') {
      await _initMlKit();
    }
  }

  Future<void> _initMlKit() async {
    if (_isInitStarted) return;
    _isInitStarted = true;
    try {
      final modelManager = OnDeviceTranslatorModelManager();
      _isModelReady = await modelManager.isModelDownloaded(TranslateLanguage.tamil.bcpCode);
      if (!_isModelReady) {
        _isModelReady = await modelManager.downloadModel(TranslateLanguage.tamil.bcpCode);
      }
      if (_isModelReady) {
        _translator = OnDeviceTranslator(
          sourceLanguage: TranslateLanguage.english,
          targetLanguage: TranslateLanguage.tamil,
        );
      }
      notifyListeners();
    } catch (e) {
      debugPrint("ML Kit init error: $e");
    } finally {
      _isInitStarted = false;
    }
  }

  Future<void> changeLanguage(String newLanguage) async {
    if (_currentLanguage == newLanguage) return;
    
    _currentLanguage = newLanguage;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language', newLanguage);
    
    if (newLanguage == 'Tamil' && !_isModelReady) {
      notifyListeners(); // Update to show English temporarily
      await _initMlKit();
    } else {
      notifyListeners();
    }
  }

  String translate(String englishText) {
    if (_currentLanguage == 'English') return englishText;
    
    if (_cache.containsKey(englishText)) {
      return _cache[englishText]!;
    }
    
    if (_isModelReady && _translator != null) {
      // Background translation
      _translator!.translateText(englishText).then((translated) {
        if (_cache[englishText] != translated) {
          _cache[englishText] = translated;
          notifyListeners(); // Force UI update when translation finishes
        }
      });
    }
    
    // Return original text while translating or downloading model
    return englishText; 
  }
}
